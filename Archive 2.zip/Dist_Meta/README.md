# Team 6 FFF Slicer

This is a class project undertaken by students at Clemson University. It's purpose is to take STL files and output GCode to a FFF (Fused Filament Fabrication, AKA FDM) printer. 

Date: Jan - Apr, 2022
Authors: William Hawthorne, John Mcadams, John Morris, Rishikesh Reddy Patlolla